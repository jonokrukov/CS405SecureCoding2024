// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// Added to include std::exception for the custom exception class
#include <exception>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    // Constructor sets exception message
    CustomException(const char* message) : msg_(message) {}

    virtual const char* what() const noexcept override {
        // Return exception message when what() is called
        return msg_;
    }

private:
    // Member variable to store exception message
    const char* msg_;
};

bool do_even_more_custom_application_logic()
{
    // Throw standard exception
    throw std::runtime_error("Standard exception thrown during do_even_more_custom_application_logic()");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Try block for catching exceptions
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    // Catch any exception derived from std::exception
    catch (const std::exception& ex) {
        // Print exception's what() message when exception is caught
        std::cout << "Exception caught in do_custom_application_logic: " << ex.what() << std::endl;
    }
    

    // Throw custom exception derived from std::exception
    throw CustomException("Custom exception thrown in do_custom_application_logic");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // Throw overflow_error exception if an attempt to divide by zero is made
    if (den == 0) {
        throw std::overflow_error("Divide by zero exception");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    // Try block to catch exceptions from divide()
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    // Only catch overflow_error exceptions thrown by divide()
    // Print exception message if exception is caught
    catch (const std::overflow_error& ex) {
        std::cout << "Exception caught in do_division: " << ex.what() << std::endl;
    }

}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // Try block for main function calls
    try {
        do_division();
        do_custom_application_logic();
    }
    // Catch CustomException and print exception message
    catch (const CustomException& ex) {
        std::cout << "CustomException caught in main: " << ex.what() << std::endl;
    }

    // Catch standard exceptions and print exception message
    catch (const std::exception& ex) {
        std::cout << "Standard exception caught in main: " << ex.what() << std::endl;
    }

    // Catch any uncaught exceptions and print exception message
    catch (...) {
        std::cout << "Unknown exception caught in main" << std::endl;
    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu